function dochange(message){
  alert(message);
}

function pick(){
  var choice = confirm('Are you sure?');
  var message
  
  if (choice == true){
    message="You pressed OK!";
  }else{
    message = "Are you sure you want to cancel?";
  };
  
  dochange(message);
}